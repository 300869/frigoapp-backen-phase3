"""
APScheduler job to execute the alert scan at startup and every N minutes.
"""
from __future__ import annotations
import os
from datetime import datetime
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger

from sqlalchemy.orm import Session

try:
    from app.database import SessionLocal  # typical SQLAlchemy session factory
except Exception:
    from ..database import SessionLocal  # type: ignore

from app.services.alert_runner import run_alert_scan

def _scan_job():
    db: Session = SessionLocal()
    try:
        written = run_alert_scan(db)
        print(f"[{datetime.utcnow().isoformat()}] Alert scan done → {written} upserts")
    finally:
        db.close()

def start_scheduler():
    interval_min = int(os.getenv("ALERT_SCAN_INTERVAL_MIN", "15"))
    scheduler = BackgroundScheduler(timezone="UTC")
    scheduler.add_job(_scan_job, trigger=IntervalTrigger(minutes=interval_min), id="alert-scan", replace_existing=True)
    # Run once immediately on startup
    _scan_job()
    scheduler.start()
    return scheduler
