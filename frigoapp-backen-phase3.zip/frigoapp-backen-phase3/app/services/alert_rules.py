"""
Alert rule engine for FrigoApp — patched to your ENUMs:
  - alertstatus: OPEN | DONE
  - alertkind:   PERIME | BIENTOT | STOCK_BAS
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import date, timedelta
from typing import Iterable, List, Optional

# ---- ENUM mappings to DB -------------------------------------------------
# All alerts produced by the rule engine are created with status OPEN.
STATUS_OPEN = "OPEN"
STATUS_DONE = "DONE"

KIND_PERIME = "PERIME"       # expired
KIND_BIENTOT = "BIENTOT"     # expiring soon
KIND_STOCK_BAS = "STOCK_BAS" # out of stock

# ---- Domain inputs -------------------------------------------------------
@dataclass(frozen=True)
class InventoryRow:
    product_id: int
    user_id: Optional[int]
    product_name: str
    quantity: float
    expiration_date: Optional[date]

# ---- Domain outputs ------------------------------------------------------
@dataclass(frozen=True)
class AlertCandidate:
    product_id: int
    user_id: Optional[int]
    kind: str                 # PERIME | BIENTOT | STOCK_BAS
    status: str               # OPEN | DONE (always OPEN for new candidates)
    message: str
    severity: str             # HIGH | MEDIUM | LOW
    due_at: Optional[date] = None

DEFAULT_EXPIRY_SOON_DAYS = 3

def classify_row(row: InventoryRow, today: Optional[date] = None, expiring_soon_days: int = DEFAULT_EXPIRY_SOON_DAYS) -> List[AlertCandidate]:
    if today is None:
        today = date.today()

    alerts: List[AlertCandidate] = []

    # STOCK_BAS → quantity <= 0
    if row.quantity is not None and row.quantity <= 0:
        alerts.append(AlertCandidate(
            product_id=row.product_id,
            user_id=row.user_id,
            kind=KIND_STOCK_BAS,
            status=STATUS_OPEN,
            message=f"Stock épuisé pour '{row.product_name}'.",
            severity="MEDIUM",
            due_at=None,
        ))
        # On ne cumule pas avec des alertes d'expiration si c'est déjà hors stock
        return alerts

    # Expiration-based
    if row.expiration_date is not None:
        if row.expiration_date < today:
            alerts.append(AlertCandidate(
                product_id=row.product_id,
                user_id=row.user_id,
                kind=KIND_PERIME,
                status=STATUS_OPEN,
                message=f"'{row.product_name}' est PÉRIMÉ depuis le {row.expiration_date.isoformat()}.",
                severity="HIGH",
                due_at=row.expiration_date,
            ))
        elif row.expiration_date <= (today + timedelta(days=expiring_soon_days)):
            alerts.append(AlertCandidate(
                product_id=row.product_id,
                user_id=row.user_id,
                kind=KIND_BIENTOT,
                status=STATUS_OPEN,
                message=f"'{row.product_name}' périme le {row.expiration_date.isoformat()}.",
                severity="MEDIUM",
                due_at=row.expiration_date,
            ))

    return alerts

def make_alerts(rows: Iterable[InventoryRow], today: Optional[date] = None, expiring_soon_days: int = DEFAULT_EXPIRY_SOON_DAYS) -> List[AlertCandidate]:
    out: List[AlertCandidate] = []
    for r in rows:
        out.extend(classify_row(r, today=today, expiring_soon_days=expiring_soon_days))
    return out
