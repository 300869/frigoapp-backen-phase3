# app/services/consumption.py
from datetime import datetime
from sqlalchemy.orm import Session

from app.schemas.consumption import ConsumptionCreate
from app.models.consumption import Consumption

def create_consumption(db: Session, payload: ConsumptionCreate) -> Consumption:
    consumed_at = payload.consumed_at or datetime.utcnow()
    obj = Consumption(
        product_id=payload.product_id,
        quantity=float(payload.quantity),
        unit=payload.unit,
        consumed_at=consumed_at,
        created_at=datetime.utcnow(),
    )
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj
