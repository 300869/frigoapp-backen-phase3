"""
Scan inventory and upsert alerts to the database using your ENUMs:
  - alertstatus: OPEN | DONE
  - alertkind:   PERIME | BIENTOT | STOCK_BAS
"""
from __future__ import annotations
from datetime import datetime, date
from typing import List, Optional

from sqlalchemy import select, and_
from sqlalchemy.orm import Session

try:
    from app.database import get_db  # optional if used as FastAPI dependency
    from app.models import Alert, Inventory, Product  # adapt if module differs
except Exception:
    from ..database import get_db  # type: ignore
    from ..models import Alert, Inventory, Product  # type: ignore

from .alert_rules import InventoryRow, make_alerts

def _load_inventory_rows(db: Session) -> List[InventoryRow]:
    q = (
        select(
            Inventory.product_id,
            Inventory.user_id,
            Product.name,
            Inventory.quantity,
            Inventory.expiration_date,
        )
        .join(Product, Product.id == Inventory.product_id)
    )
    rows = db.execute(q).all()
    out: List[InventoryRow] = []
    for product_id, user_id, name, quantity, exp_date in rows:
        out.append(InventoryRow(
            product_id=product_id,
            user_id=user_id,
            product_name=name,
            quantity=float(quantity) if quantity is not None else 0.0,
            expiration_date=exp_date
        ))
    return out

def _upsert_alert(db: Session, *, product_id: int, user_id: Optional[int],
                  kind: str, status: str, message: str,
                  severity: str, due_at: Optional[date]) -> Alert:
    """
    Avoid duplicate active alerts for same (user, product, kind).
    We don't include status in the uniqueness so that a DONE alert won't block a new OPEN one.
    """
    existing = db.execute(
        select(Alert).where(
            and_(
                Alert.product_id == product_id,
                (Alert.user_id == user_id) if user_id is not None else Alert.user_id.is_(None),
                Alert.kind == kind,
                Alert.is_active == True,
            )
        )
    ).scalars().first()

    now = datetime.utcnow()
    if existing:
        # If an active alert of same kind exists, refresh message/status/dates
        existing.status = status
        existing.message = message
        existing.severity = severity
        existing.due_at = due_at
        existing.updated_at = now
        return existing

    new_alert = Alert(
        product_id=product_id,
        user_id=user_id,
        kind=kind,
        status=status,
        message=message,
        severity=severity,
        is_active=True,
        due_at=due_at,
        created_at=now,
        updated_at=now,
    )
    db.add(new_alert)
    return new_alert

def run_alert_scan(db: Session, *, today: Optional[date] = None, expiring_soon_days: int = 3) -> int:
    inv_rows = _load_inventory_rows(db)
    candidates = make_alerts(inv_rows, today=today, expiring_soon_days=expiring_soon_days)

    count = 0
    for c in candidates:
        _upsert_alert(db,
                      product_id=c.product_id,
                      user_id=c.user_id,
                      kind=c.kind,
                      status=c.status,
                      message=c.message,
                      severity=c.severity,
                      due_at=c.due_at)
        count += 1

    db.commit()
    return count
