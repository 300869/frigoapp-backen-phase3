from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from starlette.responses import JSONResponse

from app.routers.users import router as users_router
from app.routers.categories import router as categories_router
from app.routers.products import router as products_router
from app.routers.consumptions import router as consumptions_router
from app.routers.alerts import router as alerts_router
from app.jobs.scheduler import start_scheduler
from app.api.routes import alerts as alerts_router
from app.api.routes import consumption as consumption_router

# --- JSONResponse avec charset explicite pour compat PowerShell 5 ---
class UTF8JSONResponse(JSONResponse):
    media_type = "application/json; charset=utf-8"

app = FastAPI(
    title="FrigoApp API",
    version="0.1.0",
    default_response_class=UTF8JSONResponse,  # <-- force charset=utf-8
)

@app.on_event("startup")
def on_startup():
    start_scheduler()

# --- CORS permissif pour tests locaux (Swagger/Invoke-RestMethod) ---
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],           # à restreindre en prod
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Routers ---
app.include_router(users_router)
app.include_router(categories_router)
app.include_router(products_router)
app.include_router(consumptions_router)
app.include_router(alerts_router)
app.include_router(alerts_router.router)
app.include_router(consumption_router.router)

@app.get("/", tags=["health"])  # simple healthcheck
def root():
    return {"status": "ok"}
