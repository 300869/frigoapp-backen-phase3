# app/schemas/consumption.py
from datetime import datetime
from pydantic import BaseModel, Field

class ConsumptionCreate(BaseModel):
    product_id: int = Field(gt=0)
    quantity: float = Field(gt=0)
    unit: str = Field(min_length=1, max_length=16)
    consumed_at: datetime | None = None

class ConsumptionOut(BaseModel):
    id: int
    product_id: int
    quantity: float
    unit: str
    consumed_at: datetime
    created_at: datetime

    class Config:
        from_attributes = True  # Pydantic v2
