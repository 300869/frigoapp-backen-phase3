# app/routers/consumptions.py
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.dependencies import get_db
from app.schemas.consumption import ConsumptionCreate, ConsumptionOut
from app.services.consumption import create_consumption

router = APIRouter(prefix="/consumption", tags=["consumption"])

@router.post("/", response_model=ConsumptionOut, status_code=201)
def post_consumption(payload: ConsumptionCreate, db: Session = Depends(get_db)):
    obj = create_consumption(db, payload)
    return obj
